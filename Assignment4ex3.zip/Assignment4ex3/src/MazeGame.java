import java.util.*;

interface CloneablePrototype {
    CloneablePrototype clone();
}

class Room implements CloneablePrototype {
    private int roomNo;
    private Map<Direction, Wall> sides = new HashMap<>();

    public Room(int roomNo) {
        this.roomNo = roomNo;
    }

    public Wall getSide(Direction direction) {
        return sides.get(direction);
    }

    public void setSide(Direction direction, Wall wall) {
        sides.put(direction, wall);
    }

    @Override
    public Room clone() {
        Room cloneRoom = new Room(this.roomNo);
        cloneRoom.sides = new HashMap<>(this.sides);
        return cloneRoom;
    }
}

class Wall implements CloneablePrototype {
    @Override
    public Wall clone() {
        return new Wall();
    }
}

class DoorWall extends Wall implements CloneablePrototype {
    private Room r1;
    private Room r2;
    private boolean isOpen;

    public DoorWall(Room r1, Room r2) {
        this.r1 = r1;
        this.r2 = r2;
        this.isOpen = false;
    }

    @Override
    public DoorWall clone() {
        return new DoorWall(this.r1, this.r2);
    }
}

class NewWall extends Wall implements CloneablePrototype {
    @Override
    public NewWall clone() {
        return new NewWall();
    }
}

enum Direction {
    NORTH,
    EAST,
    SOUTH,
    WEST
}

public class MazeGame {
    public static void main(String[] argv) {
        createMaze();
    }

    private static Maze createMaze() {
        Maze aMaze = new Maze();
        Room prototypeRoom = new Room(0);
        DoorWall prototypeDoorWall = new DoorWall(null, null);
        NewWall prototypeNewWall = new NewWall();

        Room r1 = prototypeRoom.clone();
        Room r2 = prototypeRoom.clone();
        DoorWall d = prototypeDoorWall.clone();
        NewWall newWall = prototypeNewWall.clone();

        aMaze.addRoom(r1);
        aMaze.addRoom(r2);

        r1.setSide(Direction.NORTH, d);
        r1.setSide(Direction.EAST, newWall);
        r1.setSide(Direction.SOUTH, newWall);
        r1.setSide(Direction.WEST, newWall);
        r2.setSide(Direction.NORTH, newWall);
        r2.setSide(Direction.EAST, newWall);
        r2.setSide(Direction.SOUTH, d);
        r2.setSide(Direction.WEST, newWall);

        return aMaze;
    }
}

class Maze {
    private Map<Integer, Room> rooms = new HashMap<>();

    public void addRoom(Room r) {
        rooms.put(r.hashCode(), r);
    }

    public Room roomNo(int r) {
        return rooms.get(r);
    }
}
