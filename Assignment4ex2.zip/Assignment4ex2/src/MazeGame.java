import java.util.HashMap;
import java.util.Map;

public class MazeGame {
    public static void main(String[] args) {
        MazeBuilder builder = new MazeBuilder();
        createMaze(builder);
        Maze maze = builder.build();
    }

    private static void createMaze(MazeBuilder builder) {
        Room r1 = builder.buildRoom(1);
        Room r2 = builder.buildRoom(2);
        DoorWall d = builder.buildDoorWall(r1, r2);

        r1.setSide(Direction.NORTH, d);
        r1.setSide(Direction.EAST, builder.buildWall());
        r1.setSide(Direction.SOUTH, builder.buildWall());
        r1.setSide(Direction.WEST, builder.buildWall());
        r2.setSide(Direction.NORTH, builder.buildWall());
        r2.setSide(Direction.EAST, builder.buildWall());
        r2.setSide(Direction.SOUTH, d);
        r2.setSide(Direction.WEST, builder.buildWall());
    }
}

class MazeBuilder {
    private Maze maze;

    public MazeBuilder() {
        maze = new Maze();
    }

    public Room buildRoom(int roomNo) {
        Room room = new Room(roomNo);
        maze.addRoom(room);
        return room;
    }

    public Wall buildWall() {
        return new Wall();
    }

    public DoorWall buildDoorWall(Room r1, Room r2) {
        return new DoorWall(r1, r2);
    }

    public Maze build() {
        return maze;
    }
}

class Maze {
    private Map<Integer, Room> rooms = new HashMap<>();

    public void addRoom(Room r) {
        rooms.put(r.getRoomNo(), r);
    }

    public Room roomNo(int r) {
        return rooms.get(r);
    }
}

enum Direction {
    NORTH,
    EAST,
    SOUTH,
    WEST
}

class Room {
    private Map<Direction, Wall> sides = new HashMap<>();
    private int roomNo;

    public Room(int roomNo) {
        this.roomNo = roomNo;
    }

    public Wall getSide(Direction direction) {
        return sides.get(direction);
    }

    public void setSide(Direction direction, Wall wall) {
        sides.put(direction, wall);
    }

    public int getRoomNo() {
        return roomNo;
    }
}

class Wall {
}

class DoorWall extends Wall {
    private Room r1;
    private Room r2;
    private boolean isOpen;

    public DoorWall(Room r1, Room r2) {
        this.r1 = r1;
        this.r2 = r2;
        this.isOpen = false;
    }
}